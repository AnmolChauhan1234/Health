DATA = [
# ── Cardiologist ──────────────────────────────────────────────────────────
("chest pain and shortness of breath",          "Cardiologist"),
("tightness in chest with sweating",            "Cardiologist"),
("heavy breathing and pain in chest",           "Cardiologist"),
("irregular heartbeat and palpitations",        "Cardiologist"),
("pain radiating to left arm and jaw",          "Cardiologist"),
("high blood pressure and dizziness",           "Cardiologist"),
("swelling in legs with chest pressure",        "Cardiologist"),
("heart attack or cardiac rest",                "Cardiologist"),

# ── Neurologist ───────────────────────────────────────────────────────────
("severe headache and dizziness",               "Neurologist"),
("migraine with sensitivity to light",          "Neurologist"),
("numbness in hands and feet",                  "Neurologist"),
("memory loss and confusion",                   "Neurologist"),
("seizures and sudden blackouts",               "Neurologist"),
("constant throbbing headache",                 "Neurologist"),
("tremors and loss of balance",                 "Neurologist"),

# ── Dermatologist ─────────────────────────────────────────────────────────
("itchy skin with red rashes",                  "Dermatologist"),
("acne and pimples on face",                    "Dermatologist"),
("dry flaky skin and eczema patches",           "Dermatologist"),
("skin rash and burning sensation",             "Dermatologist"),
("hair loss and scalp irritation",              "Dermatologist"),
("dark spots and uneven skin tone",             "Dermatologist"),
("blisters and peeling skin",                   "Dermatologist"),

# ── General Physician ─────────────────────────────────────────────────────
("fever and body aches",                        "General Physician"),
("cold and runny nose",                         "General Physician"),
("persistent cough and sore throat",            "General Physician"),
("fatigue and mild headache",                   "General Physician"),
("flu symptoms and chills",                     "General Physician"),
("fever with loss of appetite",                 "General Physician"),
("sneezing and nasal congestion",               "General Physician"),

# ── Gastroenterologist ────────────────────────────────────────────────────
("stomach pain and vomiting",                   "Gastroenterologist"),
("nausea and indigestion after eating",         "Gastroenterologist"),
("acidity and heartburn",                       "Gastroenterologist"),
("bloating and loose stools",                   "Gastroenterologist"),
("blood in stool and constipation",             "Gastroenterologist"),
("severe abdominal cramps",                     "Gastroenterologist"),
("acid reflux and difficulty swallowing",       "Gastroenterologist"),

# ── Orthopedist ───────────────────────────────────────────────────────────
("knee pain and swelling after walking",        "Orthopedist"),
("lower back pain and stiffness",               "Orthopedist"),
("joint pain and arthritis",                    "Orthopedist"),
("shoulder pain and limited arm movement",      "Orthopedist"),
("fracture and bone pain",                      "Orthopedist"),
("neck pain radiating to shoulders",            "Orthopedist"),

# ── Pulmonologist ─────────────────────────────────────────────────────────
("wheezing and asthma attacks",                 "Pulmonologist"),
("shortness of breath while climbing stairs",   "Pulmonologist"),
("chronic dry cough at night",                  "Pulmonologist"),
("chest congestion and mucus buildup",          "Pulmonologist"),
("difficulty breathing and low oxygen",         "Pulmonologist"),

# ── Ophthalmologist ───────────────────────────────────────────────────────
("blurry vision and eye strain",                "Ophthalmologist"),
("red itchy eyes with discharge",               "Ophthalmologist"),
("pain in eyes and light sensitivity",          "Ophthalmologist"),
("floaters and flashes in vision",              "Ophthalmologist"),
("difficulty seeing clearly at night",          "Ophthalmologist"),

# ── ENT Specialist ────────────────────────────────────────────────────────
("ear pain and partial hearing loss",           "ENT Specialist"),
("sore throat and swollen tonsils",             "ENT Specialist"),
("blocked nose and sinus pressure",             "ENT Specialist"),
("ringing sound in ears",                       "ENT Specialist"),
("hoarse voice and throat irritation",          "ENT Specialist"),

# ── Psychiatrist ──────────────────────────────────────────────────────────
("anxiety and frequent panic attacks",          "Psychiatrist"),
("depression and loss of interest",             "Psychiatrist"),
("insomnia and disturbed sleep",                "Psychiatrist"),
("mood swings and irritability",                "Psychiatrist"),
("extreme stress and overthinking",             "Psychiatrist"),]