from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.model_selection import cross_val_score
from data.data import DATA
import numpy as np
import joblib


# =============================================================================
# STEP 1 — Dataset
# Each tuple: (symptom description, specialist label)
# Multiple phrasings per specialist so the model learns varied language.
# =============================================================================


X = [symptom for symptom, label in DATA]
y = [label for symptom, label in DATA]

# =============================================================================
# STEP 2 — Build & Train the Pipeline
#
# Pipeline chains two steps automatically:
#   Step 1 — TfidfVectorizer: converts text → numeric feature matrix
#              - ngram_range=(1,2) : captures single words AND two-word phrases
#                e.g. "chest pain" is one feature, not just "chest" + "pain"
#              - stop_words="english": drops words like "and", "the", "I"
#              - sublinear_tf=True  : dampens very frequent terms
#
#   Step 2 — LogisticRegression: multi-class classifier on those features
#              - C=5               : moderate regularisation strength
#              - max_iter=1000     : enough iterations for the solver to converge
# =============================================================================

pipeline = Pipeline([
    ("tfidf", TfidfVectorizer(
        ngram_range=(1, 2),
        stop_words="english",
        sublinear_tf=True,
    )),
    ("clf", LogisticRegression(
        C=5,
        max_iter=1000,
        random_state=42,
    )),
])

# Train on the entire dataset
pipeline.fit(X, y)


joblib.dump(pipeline, "model.pkl")
print("✅ Model saved as model.pkl")


# =============================================================================
# STEP 3 — Quick Cross-Validation Check
# Gives an honest estimate of accuracy without a separate test split.
# (Uses 5-fold CV; each fold is ~20 % of the data held out for testing.)
# =============================================================================

cv_scores = cross_val_score(pipeline, X, y, cv=5, scoring="accuracy")
print("=" * 60)
print("  HealthEasy — Symptom-to-Specialist Classifier")
print("=" * 60)
# print(f"  Cross-Validation Accuracy: {np.mean(cv_scores)*100:.1f}% "
#       f"(± {np.std(cv_scores)*100:.1f}%)")
# print("=" * 60)


# =============================================================================
# STEP 4 — Prediction Function
# =============================================================================

def predict_specialist(user_input: str) -> str:
    """
    Predicts the most suitable medical specialist for a symptom description.

    Args:
        user_input (str): A natural-language symptom sentence.

    Returns:
        str: The predicted specialist label (e.g. "Cardiologist").

    Raises:
        ValueError: If the input string is empty or whitespace only.
    """
    if not user_input or not user_input.strip():
        raise ValueError("Symptom description cannot be empty.")

    # pipeline.predict expects a list; return the single prediction
    prediction = pipeline.predict([user_input.strip()])
    return prediction[0]


# =============================================================================
# STEP 5 — Interactive Console Loop
# The model is trained and ready. Now we ask the user to type their symptoms.
# Type 'quit' or 'exit' to stop the program.
# =============================================================================

print("\n  Model is ready! Describe your symptoms and get a specialist.")
print("  (Type 'quit' or 'exit' to stop)\n")

while True:
    # Prompt the user for input
    user_input = input("  Enter your symptoms: ").strip()

    # Allow the user to exit gracefully
    if user_input.lower() in ("quit", "exit", "q"):
        print("\n  Thank you for using HealthEasy. Stay healthy! 👋\n")
        break

    # Skip blank lines
    if not user_input:
        print("  ⚠  Please describe your symptoms before pressing Enter.\n")
        continue

    # Predict and display the result
    try:
        specialist = predict_specialist(user_input)
        print(f"\n  ✅ Predicted Specialist: {specialist}\n")
    except Exception as e:
        print(f"\n  ❌ Error: {e}\n")
